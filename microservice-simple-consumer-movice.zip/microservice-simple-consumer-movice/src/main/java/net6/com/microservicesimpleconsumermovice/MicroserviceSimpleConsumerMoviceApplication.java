package net6.com.microservicesimpleconsumermovice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSimpleConsumerMoviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSimpleConsumerMoviceApplication.class, args);
	}
}
